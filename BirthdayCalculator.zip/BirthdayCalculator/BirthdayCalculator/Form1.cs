﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BirthdayCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            DateTime dt = DateTime.Parse(textBox1.Text);
            try {
                if (textBox1.Text == dt.ToShortDateString())
                {
                    label2.Text = dt.ToString();
                }
                else
                {
                    MessageBox.Show("invalid date time format should be (yyyy/dd/mm)");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            
        }
    }
}
